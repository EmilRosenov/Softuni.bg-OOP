﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortageUpgraded
{
    public interface IBirthable
    {
        public string BirthDate { get; }
    }
}
