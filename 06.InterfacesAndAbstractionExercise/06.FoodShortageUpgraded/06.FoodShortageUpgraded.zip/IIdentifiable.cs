﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortageUpgraded
{
    public interface IIdentifiable
    {
        public string Id { get;}
    }
}
