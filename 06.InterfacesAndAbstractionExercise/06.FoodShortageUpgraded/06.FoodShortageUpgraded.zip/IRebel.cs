﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortageUpgraded
{
    public interface IRebel:IPerson
    {
        public string Group { get; }
    }
}
