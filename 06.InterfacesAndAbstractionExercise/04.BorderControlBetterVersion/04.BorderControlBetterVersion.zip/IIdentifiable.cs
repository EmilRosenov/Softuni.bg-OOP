﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.BorderControlBetterVersion
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
}
