﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortage
{
    interface INameable
    {
        public string Name { get; set; }
    }
}
