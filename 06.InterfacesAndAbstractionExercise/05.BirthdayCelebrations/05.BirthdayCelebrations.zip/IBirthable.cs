﻿namespace _05.BirthdayCelebrations
{
    public interface IBirthable
    {
        public string BirthDate { get;}
    }
}