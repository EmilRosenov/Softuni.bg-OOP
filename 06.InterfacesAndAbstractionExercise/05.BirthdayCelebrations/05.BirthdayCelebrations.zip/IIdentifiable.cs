﻿namespace _05.BirthdayCelebrations
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
}