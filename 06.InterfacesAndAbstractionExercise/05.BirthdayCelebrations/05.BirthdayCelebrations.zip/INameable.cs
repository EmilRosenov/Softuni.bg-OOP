﻿namespace _05.BirthdayCelebrations
{
    public  interface INameable
    {
        public string Name { get;}
    }
}