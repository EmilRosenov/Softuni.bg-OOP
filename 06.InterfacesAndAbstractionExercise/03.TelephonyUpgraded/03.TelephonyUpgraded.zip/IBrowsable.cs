﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.TelephonyUpgraded
{
    interface IBrowsable
    {
        string Browse(string url);
    }
}
