namespace Database.Tests
{
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestFixture]
    public class DatabaseTests
    {

        private Database database;
        [SetUp]
        public void Setup()
        {
            this.database = new Database();

        }

        [Test]
       
        public void Test_Add_Throws_Exception_When_Capacity_Is_Exceeded()
        {
            Database database = new Database();

            for (int i = 0; i < 16; i++)
            {
                database.Add(i);
            }

            Assert.Throws<InvalidOperationException>(() => database.Add(10));
        }

        [Test]

        public void Test_Add_Increases_Database_Count_When_Add_Is_Valid_Op()
        {
            int n = 10;

            for (int i = 0; i < n; i++)
            {
                this.database.Add(i);
            }

            Assert.That(this.database.Count==n);
        }


        [Test]

        public void Test_Add_Adds_Element_To_Database()
        {
            int element = 101;
            this.database.Add(element);
            int[] elements = this.database.Fetch();

            
            Assert.That(elements.Contains(element),Is.EqualTo(true));
        }

        [Test]

        public void Test_Remove_Throws_Exception_When_Database_Is_Empty()
        {
            Assert.Throws<InvalidOperationException>(() => this.database.Remove());
        }


        [Test]

        public void Test_Remove_Decreases_Database_Count()
        {
            this.database.Add(1);
            this.database.Add(2);
            this.database.Add(3);
            this.database.Add(4);

            this.database.Remove();
            Assert.That(this.database.Count, Is.EqualTo(3));

        }

        [Test]

        public void Test_Remove_Removes_Element_From_Database()
        {
            int lastElement = 4;
            this.database.Add(1);
            this.database.Add(2);
            this.database.Add(3);
            this.database.Add(lastElement);

            this.database.Remove();
            int[] elements = this.database.Fetch();

            Assert.IsFalse(elements.Contains(lastElement));

        }

        [Test]

        public void Test_Fetch_Returns_Database_Copy_Instead_Of_Reference()
        {
            this.database.Add(1);
            this.database.Add(2);

            int[] firstCopy = this.database.Fetch();
            
            this.database.Add(3);

            int[] secondCopy = this.database.Fetch();

            Assert.That(firstCopy != secondCopy);

        }

        [Test]

        public void Test_Count_Returns_Zero_When_Database_Empty()
        {

            Assert.That(this.database.Count, Is.EqualTo(0));
        }

        //[Test]
        
       //public void Ctor_Throws_Exception_When_Database_Capacity_Exceeded()
       //{
       //    int[] arr = new[] { 1, 2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17};
       //    
       //    this.database = new Database(arr);
       //    Assert.Throws<InvalidOperationException>(() =>this.database());
       //
       //}

        [Test]

        public void Ctor_Adds_Elements_To_Database()
        {

            int[] arr = new[] { 1, 2, 3 };

            this.database = new Database(arr);

            Assert.That(this.database.Count, Is.EqualTo(arr.Length));
            Assert.That(this.database.Fetch(), Is.EquivalentTo(arr));
        }
    }
}
