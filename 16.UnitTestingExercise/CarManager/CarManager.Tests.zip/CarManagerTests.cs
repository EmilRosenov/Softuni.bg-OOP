namespace CarManager.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class CarManagerTests
    {
        [Test]
        [TestCase(null,"model",10,100)]
        [TestCase("", "model", 10, 100)]
        
        public void Ctor_Input_For_Make_Throws_Exception_When_DataInput_Null_Or_Empty(
            string make,
            string model, 
            double fuelConsumption, 
            double fuelCapacity)
        {
            Assert.Throws<ArgumentException>(()=> new Car(make, model, fuelConsumption, fuelCapacity));
        }

        [Test]
        [TestCase("make", null, 10, 100)]
        [TestCase("make", "", 10, 100)]
        public void Ctor_Input_For_Model_Throws_Exception_When_DataInput_Null_Or_Empty(
           string make,
           string model,
           double fuelConsumption,
           double fuelCapacity)
        {
            Assert.Throws<ArgumentException>(() => new Car(make, model, fuelConsumption, fuelCapacity));
        }

        [Test]
        [TestCase("make", "model", -10, 100)]
        [TestCase("make", "model", 0, 100)]
        public void Ctor_Input_For_FuelConsumption_Throws_Exception_When_Input_LessOrEqualToZero(
           string make,
           string model,
           double fuelConsumption,
           double fuelCapacity)
        {
            Assert.Throws<ArgumentException>(() => new Car(make, model, fuelConsumption, fuelCapacity));
        }

        [Test]
        [TestCase("make", "model", 10, -1)]
        [TestCase("make", "model", 20, -10)]
        public void Ctor_Input_For_FuelAmount_Throws_Exception_When_Input_Less_Than_Zero(
           string make,
           string model,
           double fuelConsumption,
           double fuelCapacity)
        {
            Assert.Throws<ArgumentException>(() => new Car(make, model, fuelConsumption, fuelCapacity));
        }

        [Test]
        [TestCase(-1)]
        [TestCase(0)]
        public void Refuel_Test_Throws_Exception_When_Input_Zero_Or_Less(double fuelToRefuel)
        {
            Car car = new Car("make", "model", 10, 100);
            Assert.Throws<ArgumentException>(() => car.Refuel(fuelToRefuel));
        }

        [Test]
        [TestCase(30)]
        //[TestCase(31)]
        public void Refuel_Increases_FuelAmount_When_FuelToRefuel_Is_Valid(double fuelToRefuel)
        {
            Car car = new Car("make", "model", 10, 100);
            car.Refuel(fuelToRefuel);
            car.Refuel(fuelToRefuel);
            Assert.AreEqual(car.FuelAmount, 60);
        }

        [Test]
        [TestCase(110)]
        //[TestCase(31)]
        public void Refuel_Sets_FuelAmount_To_Capacity_When_Capacity_Is_Exceeded(double fuelToRefuel)
        {
            Car car = new Car("make", "model", 10, 100);
            car.Refuel(fuelToRefuel);
            Assert.AreEqual(car.FuelAmount, car.FuelCapacity);

        }

        [Test]
        [TestCase(1600)]
        [TestCase(1500)]
        public void Drive_Throws_Exception_When_FuelAmount_Is_Less_Than_FuelNeeded(double distance)
        {
            Car car = new Car("make","model", 6, 80);
            double fuelNeeded = (distance / 100) * car.FuelConsumption;
            Assert.Throws<InvalidOperationException>(() => car.Drive(distance));
        }

        [Test]
        [TestCase(1000)]
        //[TestCase(1100)]
        public void Drive_Decreases_FuelAmount_When_Distance_Is_Valid(double distance)
        {
            Car car = new Car("make", "model", 6, 80);
            double fuelNeeded = (distance / 100) * car.FuelConsumption;

            car.Refuel(80);
            car.Drive(distance);
            Assert.AreEqual(car.FuelAmount, 80 - fuelNeeded);
        }

        
    }
}