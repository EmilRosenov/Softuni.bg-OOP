namespace DatabaseExtended.Tests
{
    using ExtendedDatabase;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    public class ExtendedDatabaseTests
    {
        private Database extendedDatabase;
        [SetUp]
        public void Setup()
        {
            this.extendedDatabase = new Database();
        }
        [Test]

        public void Test_Add_Throws_Exception_When_Capacity_Equal_Or_Exceeded()
        {
            List<Person> persons = new List<Person>();
            for (long i = 0; i < 16; i++)
            {
                Person person = new Person(i, $"Username{i}");
                this.extendedDatabase.Add(person);
            }
            Assert.Throws<InvalidOperationException>(() => this.extendedDatabase.Add(new Person(16, "Username")));
        }
        [Test]

        public void Test_Add_Increases_Counter_When_Valid_Data()
        {

            for (long i = 0; i < 5; i++)
            {
                Person person = new Person(i, $"Username{i}");
                this.extendedDatabase.Add(person);
            }
            int expectedOutput = 5;
            Assert.That(expectedOutput, Is.EqualTo(extendedDatabase.Count));
        }

        [Test]

        public void Test_Add_Throws_Exception_When_Username_Invalid()
        {
            for (int i = 0; i < 3; i++)
            {
                Person person = new Person(i, $"name{i}");
                extendedDatabase.Add(person);
            }

            Assert.Throws<InvalidOperationException>(() => extendedDatabase.Add(new Person(2, "name2")));
        }
        [Test]

        public void Test_Add_Throws_Exception_When_Id_Invalid()
        {
            for (int i = 0; i < 3; i++)
            {
                Person person = new Person(i, $"name{i}");
                extendedDatabase.Add(person);
            }

            Assert.Throws<InvalidOperationException>(() => extendedDatabase.Add(new Person(1, "name6")));
        }

        [Test]
        public void Test_Remove_Throws_Exception_When_Collection_Is_Empty()
        {
            Assert.Throws<InvalidOperationException>(() => this.extendedDatabase.Remove());
        }

        [Test]
        public void Test_Remove_Decreases_Counter()
        {
            int n = 5;
            for (int i = 0; i < n; i++)
            {
                Person person = new Person(i, $"name{i}");
                extendedDatabase.Add(person);
            }
            extendedDatabase.Remove();
            extendedDatabase.Remove();

            Assert.AreEqual(n - 2, extendedDatabase.Count);
        }

        
        [Test]
        public void Ctor_Throws_Exception_When_Capacity_Exceeded()
        {
            Person[] arguments = new Person[17];

            for (int i = 0; i < arguments.Length; i++)
            {
                arguments[i] = new Person(i, $"Username{i}");
            }

            Assert.Throws<ArgumentException>(() => this.extendedDatabase = new ExtendedDatabase.Database(arguments));
        }

        [Test]
        public void Ctor_Adds_Initial_People()
        {
            Person[] arguments = new Person[10];

            for (int i = 0; i < arguments.Length; i++)
            {
                arguments[i] = new Person(i, $"Username{i}");
                this.extendedDatabase.Add(arguments[i]);
            }

            this.extendedDatabase = new ExtendedDatabase.Database(arguments);
            Assert.That(this.extendedDatabase.Count, Is.EqualTo(arguments.Length));

            foreach (var person in arguments)
            {
                Person dbPerson = this.extendedDatabase.FindById(person.Id);
                Assert.That(person, Is.EqualTo(dbPerson));
            }
        }
        [Test]
        [TestCase(null)]
        [TestCase("")]
        //[TestCase(" ")]
        public void Test_FindByUserName_Throws_Exception_When_NullOrEmpty(string name)
        {
            Assert.Throws<ArgumentNullException>(() => this.extendedDatabase.FindByUsername(name));
        }

        [Test]
        [TestCase("Steven")]
        [TestCase("Carragher")]
        //[TestCase(" ")]
        public void Test_FindByUserName_Throws_Exception_When_UserName_Does_Not_Exist(string name)
        {
            for (int i = 0; i < 5; i++)
            {
                Person person = new Person(i, $"user{i}");
                this.extendedDatabase.Add(person);
            }

            Assert.Throws<InvalidOperationException>(() => this.extendedDatabase.FindByUsername(name));
        }
        [Test]
        [TestCase("Steven")]
        [TestCase("Carragher")]
        //[TestCase(" ")]
        public void Test_FindByUserName_Returns_Expected_Outcome(string name)
        {
            Person person = new Person(1, $"user");
            Person personOne = new Person(2, $"userOne");
            Person personTwo = new Person(3, $"{name}");
            //Person personThree = new Person(1, $"Carragher");
            this.extendedDatabase.Add(person);
            this.extendedDatabase.Add(personOne);
            this.extendedDatabase.Add(personTwo);
            //this.extendedDatabase.Add(personThree);

            Assert.That(this.extendedDatabase.FindByUsername(name),Is.EqualTo(personTwo));
        }

        [Test]
        [TestCase(-1)]
        [TestCase(-100)]
        public void Test_FindById_Throws_Exception_When_LessThanZero(long id)
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => this.extendedDatabase.FindById(id));
        }


        [Test]
        [TestCase(20)]
        [TestCase(18)]
        public void Test_FindById_Throws_Exception_When_UserIdDoesNotExist(long id)
        {
            for (int i = 0; i < 5; i++)
            {
                Person person = new Person(i, $"user{i}");
                this.extendedDatabase.Add(person);
            }
            
            Assert.Throws<InvalidOperationException>(() => this.extendedDatabase.FindById(id));
        }

        [Test]
        [TestCase(2)]
        [TestCase(5)]
        public void Test_FindById_Returns_Expected_Outcome(long id)
        {
            Person person = new Person(1, $"user{1}");
            Person personOne = new Person(id, $"user{2}");
            Person personTwo = new Person(3, $"user3");
            this.extendedDatabase.Add(person);
            this.extendedDatabase.Add(personOne);
            this.extendedDatabase.Add(personTwo);
            
            Assert.That(this.extendedDatabase.FindById(id),Is.EqualTo(personOne));
        }
    }
}