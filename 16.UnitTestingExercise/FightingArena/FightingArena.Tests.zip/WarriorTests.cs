namespace FightingArena.Tests
{
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class WarriorTests
    {

        [Test]
        [TestCase(null, 100, 100)]
        [TestCase(" ", 100, 100)]
        [TestCase("", 100, 100)]
        public void Ctor_Throws_Exception_When_Name_Is_Null_Or_WhiteSpace(string name, int damage, int hp)
        {
            Assert.Throws<ArgumentException>(() => new Warrior(name, damage, hp));
        }


        [Test]
        [TestCase("Warior", 0, 100)]
        [TestCase("Warrior", -1, 100)]
        public void Ctor_Throws_Exception_When_Damage_Is_Zero_Or_Negative(string name, int damage, int hp)
        {
            Assert.Throws<ArgumentException>(() => new Warrior(name, damage, hp));
        }


        [Test]
        [TestCase("Warrior", 100, -1)]
        public void Ctor_Throws_Exception_When_HP_Is_Zero_Or_Negative(string name, int damage, int hp)
        {
            Assert.Throws<ArgumentException>(() => new Warrior(name, damage, hp));
        }


        [Test]
        [TestCase(30, 55)]
        [TestCase(15, 55)]
        [TestCase(55, 30)]
        [TestCase(55, 15)]
        public void Attack_Throws_Exception_When_Hp_Lower_Than_The_Minimum_HP(int attackerHp, int warriorHP)
        {
            Warrior attacker = new Warrior("Emil", 31, attackerHp);
            Warrior warrior = new Warrior("Enemy", 30, warriorHP);
            Assert.Throws<InvalidOperationException>(() => attacker.Attack(warrior));
        }


        [Test]
        public void Attack_Throws_Exception_When_Warrior_Kills_Attacker()
        {
            Warrior attacker = new Warrior("Emil", 31, 50);
            Warrior warrior = new Warrior("Enemy", attacker.HP + 1, 32);
            Assert.Throws<InvalidOperationException>(() => attacker.Attack(warrior));
        }


        [Test]
        public void Attack_Decreases_Attackers_Hp()
        {
            //name,damage,hp
            Warrior attacker = new Warrior("Emil", 31, 50);
            Warrior warrior = new Warrior("Enemy", 41, 32);
            attacker.Attack(warrior);
            Assert.AreEqual(9, attacker.HP);
        }


        [Test]
        public void Attack_Decreases_Warriors_Hp()
        {
            //name,damage,hp
            Warrior attacker = new Warrior("Emil", 31, 50);
            Warrior warrior = new Warrior("Enemy", 41, 50);
            warrior.Attack(attacker);
            Assert.AreEqual(19, warrior.HP);
        }


        [Test]
        public void Attack_Sets_Warriors_HP_To_Zero_When_Warrior_Killed()
        {
            //name,damage,hp
            Warrior attacker = new Warrior("Emil", 55, 50);
            Warrior warrior = new Warrior("Enemy", 41, 50);
            attacker.Attack(warrior);
            Assert.AreEqual(0, warrior.HP);
        }

        //this.HP -= warrior.Damage;
        //
        //   if (this.Damage > warrior.HP)
        //   {
        //   warrior.HP = 0;
        //
        //   else
        //   {
        //   warrior.HP -= this.Damage;
    }
}