﻿namespace FightingArena.Tests
{
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    [TestFixture]
    public class ArenaTests
    {
        private Arena arena;
        [SetUp]
        public void Setup()
        {
            this.arena = new Arena();
        }

        [Test]
        public void Ctor_Initializes_Warrior()
        {
            Assert.That(arena.Warriors, Is.Not.Null);
        }


        [Test]
        public void Count_Is_Zero_When_Arena_Is_Empty()
        {
            Assert.That(arena.Count, Is.EqualTo(0));
        }


        [Test]
        public void Count_Is_Increased_When_Warrior_Is_Enrolled()
        {
            Warrior warrior = new Warrior("name", 50, 50);
            arena.Enroll(warrior);
            Assert.That(arena.Count, Is.EqualTo(1));
        }

        [Test]
        public void Enroll_Throws_Exception_When_Warrior_Allready_Enrolled()
        {
            Warrior warrior = new Warrior("name", 50, 50);
            Warrior warriorTwo = new Warrior("name", 50, 50);
            arena.Enroll(warrior);
            Assert.Throws<InvalidOperationException>(() => arena.Enroll(warrior));

        }

        [Test]
        public void Enroll_Adds_Warrior_To_Warriors()
        {
            string name = "Warrior";
            arena.Enroll(new Warrior(name, 50, 50));
            Assert.That(arena.Warriors.Any(x => x.Name == x.Name), Is.True);
        }

       
        [Test]
        [TestCase("Emil", "Nikolay")]
        [TestCase("Nikolay", "Emil")]
        
        public void Fight_Attacker_And_Defender_Fighting_Reduces_Attackers_HP(string attackerName, string defenderName)
        {
            int initialHP = 100;
            //int initialDamage = 100;
            Warrior attacker = new Warrior(attackerName, 50, initialHP);
            Warrior defender = new Warrior(defenderName, 50, initialHP);
            arena.Enroll(attacker);
            arena.Enroll(defender);

            arena.Fight(attacker.Name, defender.Name);
            Assert.AreEqual(attacker.HP, initialHP - defender.Damage);
            Assert.AreEqual(defender.HP, initialHP - attacker.Damage);
        }


        [Test]
        public void Fight_Throws_Exception_When_Defender_Does_Not_Exist()
        {
            string attacker = "Attacker";
            arena.Enroll(new Warrior(attacker, 40, 40));
            Assert.Throws<InvalidOperationException>(() => arena.Fight(attacker, "Defender"));
        }


        [Test]
        public void Fight_Throws_Exception_When_Attacker_Does_Not_Exist()
        {
            string defender = "Defender";
            arena.Enroll(new Warrior(defender, 40, 40));
            Assert.Throws<InvalidOperationException>(() => arena.Fight(defender, "Attacker"));
        }

        [Test]
        public void Fight_Throws_Exception_When_Both_Do_Not_Exist()
        {
            Assert.Throws<InvalidOperationException>(() => arena.Fight("Defender", "Attacker"));
        }
        
    }
}
