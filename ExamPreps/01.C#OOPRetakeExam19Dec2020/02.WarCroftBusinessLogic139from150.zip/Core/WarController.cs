﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WarCroft.Constants;
using WarCroft.Entities.Characters;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Items;

namespace WarCroft.Core
{
	public class WarController
	{
		private readonly List<Character> party;
		private readonly List<Item> itemsList;
		public WarController()
		{
			this.party = new List<Character>();
			this.itemsList = new List<Item>();
		}

		public string JoinParty(string[] args)
		{
			string characterType = args[0];
			string name = args[1];

			Character character = null; ;

            if (characterType==nameof(Warrior))
            {
				character = new Warrior(name);
            }
            else if (characterType == nameof(Priest))
            {
				character = new Priest(name);
            }
            else
            {
				throw new ArgumentException(
					string.Format
					(ExceptionMessages.InvalidCharacterType,
					characterType));

			}

			this.party.Add(character);
			return string.Format(SuccessMessages.JoinParty, name);
		}

		public string AddItemToPool(string[] args)
		{
			string itemName = args[0];
			Item item = null;
            if (itemName.Equals(nameof(HealthPotion)))
            {
				item = new HealthPotion();

			}
            else if (itemName.Equals(nameof(FirePotion)))
            {
				item = new FirePotion();
			}
            else
            {
				throw new ArgumentException(
					string.Format
					(ExceptionMessages.InvalidItem,
					itemName));
			}
			this.itemsList.Add(item);
			return string.Format(SuccessMessages.AddItemToPool, itemName);

		}

		public string PickUpItem(string[] args)
		{
			string characterName = args[0];

			Character character = this.party.FirstOrDefault(x => x.Name == characterName);
            if (character==null)
            {
				throw new ArgumentException(
					string.Format(ExceptionMessages.CharacterNotInParty, characterName));
            }
            if (!this.itemsList.Any())
            {
				throw new InvalidOperationException(ExceptionMessages.ItemPoolEmpty);
            }

			Item itemToAdd = itemsList.LastOrDefault();
			this.itemsList.Remove(itemToAdd);
			character.Bag.AddItem(itemToAdd);

			return string.Format(SuccessMessages.PickUpItem, characterName, itemToAdd);

		}

		public string UseItem(string[] args)
		{
			string characterName = args[0];
			string itemName = args[1];

			Character character = this.party.FirstOrDefault(x => x.Name == characterName);
            if (character == null)
            {
				throw new ArgumentException(
					string.Format(ExceptionMessages.CharacterNotInParty, characterName));

			}
            if (!itemsList.Any())
            {
				throw new InvalidOperationException(ExceptionMessages.ItemPoolEmpty);
			}

			Item itemToUse = this.itemsList.FirstOrDefault(x => x.GetType().Name == itemName);
            if (itemToUse==null)
            {
				throw new ArgumentException(
					string.Format(ExceptionMessages.ItemNotFoundInBag
					, itemName));
            }

			itemToUse.AffectCharacter(character);
			return string.Format(SuccessMessages.UsedItem, characterName, itemName);
		}

		public string GetStats()
		{
			StringBuilder sb = new StringBuilder();
            foreach (var character in this.party.OrderByDescending(x=>x.IsAlive)
											.ThenByDescending(y=>y.Health))
            {
				//{name} - HP: {health}/{baseHealth}, AP: {armor}/{baseArmor}, Status: {Alive/Dead}
				sb.AppendLine(string.Format(SuccessMessages.CharacterStats,
											character.Name, character.Health,
											character.BaseHealth, character.Armor,
											character.BaseArmor,
											character.IsAlive ? "Alive" : "Dead"));
			}
			return sb.ToString().TrimEnd();
		}

		public string Attack(string[] args)
		{
			string attackerName = args[0];
			string recieverName = args[1];

			Character attacker = this.party.FirstOrDefault(x => x.Name == attackerName);
            if (attacker == null)
            {
				throw new ArgumentException(string.Format(
					ExceptionMessages.CharacterNotInParty,
					attacker));

			}

			Character reciever = this.party.FirstOrDefault(x => x.Name == recieverName);
            if (reciever==null)
            {
				throw new ArgumentException(string.Format(
					ExceptionMessages.CharacterNotInParty,
					reciever));
			}

            if (!(attacker is IAttacker))
            {
				throw new ArgumentException($"{attackerName} cannot attack!");

			}

			((IAttacker)attacker).Attack(reciever);
			StringBuilder sb = new StringBuilder();
			string result = string.Format(SuccessMessages.AttackCharacter, attacker.Name, reciever.Name
					, attacker.AbilityPoints, reciever.Name, reciever.Health, reciever.BaseHealth
					, reciever.Armor, reciever.BaseArmor);
			sb.AppendLine(result);

			if (!reciever.IsAlive)
            {
				string deadResult = string.Format(SuccessMessages.AttackKillsCharacter, reciever.Name);
				sb.AppendLine(deadResult);
            }

			return sb.ToString().TrimEnd();
		}

		public string Heal(string[] args)
		{
			string healerName = args[0];
			string healingRecieverNAme = args[1];

			Character healer = this.party.FirstOrDefault(x => x.Name == healerName);
			Character reciever = this.party.FirstOrDefault(x => x.Name == healingRecieverNAme);

            if (healer==null)
            {
				throw new ArgumentException(
					string.Format(
						ExceptionMessages.CharacterNotInParty,
						healerName));
            }
			if (reciever == null)
			{
				throw new ArgumentException(
					string.Format(
						ExceptionMessages.CharacterNotInParty,
						healingRecieverNAme));
			}

            if (!(healer is IHealer))
            {
				throw new ArgumentException($"{healerName} cannot heal!");
					

			}

			((IHealer)healer).Heal(reciever);

			string result = string.Format(SuccessMessages.HealCharacter,
								healer.Name, reciever.Name,
								healer.AbilityPoints, reciever.Name,
								reciever.Health);
			return result;
		}
	}
}
