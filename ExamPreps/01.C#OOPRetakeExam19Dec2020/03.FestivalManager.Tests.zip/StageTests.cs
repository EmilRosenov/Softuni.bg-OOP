// Use this file for your unit tests.
// When you are ready to submit, REMOVE all using statements to Festival Manager (entities/controllers/etc)
// Test ONLY the Stage class. 
namespace FestivalManager.Tests
{
    
    using NUnit.Framework;
    using System;

    [TestFixture]
    public class StageTests
    {
        [Test]
        public void Initialize_Ctor_Initialize_All_Collections()
        {
            Stage stage = new Stage();

            Assert.IsNotNull(stage.Performers);
        }

        [Test]
        public void Validate_AddPerformer()
        {
            Stage stage = new Stage();
            Assert.Throws<ArgumentNullException>(() => stage.AddPerformer(null));
            Assert.Throws<ArgumentException>(() => stage.AddPerformer(new Performer("Emil", "Velichkov", 16)));

            Performer performer = new Performer("Emil", "Velichkov", 35);
            stage.AddPerformer(performer);
            Assert.AreEqual(1, stage.Performers.Count);
        }

        //Assert.Throws<ArgumentNullException>(() => stage.AddSong(null));
        [Test]
        public void Validate_AddSong()
        {
            Stage stage = new Stage();
            Assert.Throws<ArgumentNullException>(() => stage.AddSong(null));
            Assert.Throws<ArgumentException>(() => stage.AddSong(new Song("You", TimeSpan.FromSeconds(59))));

            Song song = new Song("You",TimeSpan.FromSeconds(180));
            stage.AddSong(song);
        }


        [Test]
        public void Validate_AddSongToPerformer()
        {
            Stage stage = new Stage();
            Assert.Throws<ArgumentNullException>(() 
                   => stage.AddSongToPerformer(null,"TestName"));
            Assert.Throws<ArgumentNullException>(()
                   => stage.AddSongToPerformer("TestSong", null));

            Assert.Throws<ArgumentException>(()
                   => stage.AddSongToPerformer("TestSong", "TestName"));

            Performer performer = new Performer("Emil", "Velichkov", 35);
            stage.AddPerformer(performer);

            Assert.Throws<ArgumentException>(()
                  => stage.AddSongToPerformer("TestSong", performer.FullName));

            Song song = new Song("You", TimeSpan.FromSeconds(180));
            stage.AddSong(song);

            string result = stage.AddSongToPerformer(song.Name, performer.FullName);
            Assert.True(performer.SongList.Contains(song));
            Assert.AreEqual(result, $"{song} will be performed by {performer}");  
        }

        [Test]
        public void Validate_Play()
        {
            Stage stage = new Stage();
            Performer velichkov = new Performer("Emil", "Velichkov", 26);
            Performer dakov = new Performer("viktor", "Dakov", 26);
            Performer shopov = new Performer("Stoyan", "Shopov", 26);

            Song song1 = new Song("Me", TimeSpan.FromSeconds(180));
            Song song2 = new Song("You", TimeSpan.FromSeconds(180));
            Song song3 = new Song("He", TimeSpan.FromSeconds(180));
            Song song4 = new Song("She", TimeSpan.FromSeconds(180));
            Song song5 = new Song("We", TimeSpan.FromSeconds(180));

            stage.AddPerformer(velichkov);
            stage.AddPerformer(dakov);
            stage.AddPerformer(shopov);

            stage.AddSong(song1);
            stage.AddSong(song2);
            stage.AddSong(song3);
            stage.AddSong(song4);
            stage.AddSong(song5);

            stage.AddSongToPerformer(song1.Name, velichkov.FullName);
            stage.AddSongToPerformer(song2.Name, velichkov.FullName);
            stage.AddSongToPerformer(song3.Name, velichkov.FullName);


            stage.AddSongToPerformer(song4.Name, dakov.FullName);
            stage.AddSongToPerformer(song5.Name, dakov.FullName);

            string result = stage.Play();

            Assert.AreEqual(result, $"{stage.Performers.Count} performers played {5} songs");
        }
    }
}