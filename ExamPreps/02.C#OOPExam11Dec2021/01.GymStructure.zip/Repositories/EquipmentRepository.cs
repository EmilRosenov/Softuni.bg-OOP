﻿using Gym.Models.Equipment.Contracts;
using Gym.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gym.Repositories
{
    public class EquipmentRepository : IRepository<IEquipment>
    {
        private  readonly List<IEquipment> equipmentModels;
        public EquipmentRepository()
        {
            this.equipmentModels = new List<IEquipment>();
        }
        public IReadOnlyCollection<IEquipment> Models => this.equipmentModels;

        public void Add(IEquipment model)
        {
            this.equipmentModels.Add(model);
        }

        public IEquipment FindByType(string type)
        {
            IEquipment searchedModel = equipmentModels.FirstOrDefault(x => x.GetType().Name == type);

            if (searchedModel==null)
            {
                return null;
            }
            return searchedModel;
        }

        public bool Remove(IEquipment model)
        {
            return this.equipmentModels.Remove(model);
        }
    }
}

   
