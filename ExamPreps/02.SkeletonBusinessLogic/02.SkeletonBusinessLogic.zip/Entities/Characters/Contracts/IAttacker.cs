﻿namespace WarCroft.Entities.Characters.Contracts
{
	public interface IAttacker
	{
		void Attack(Character character);
	}
}