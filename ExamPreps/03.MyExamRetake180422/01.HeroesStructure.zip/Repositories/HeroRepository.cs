﻿using Heroes.Models.Contracts;
using Heroes.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heroes.Repositories
{
    public class HeroRepository : IRepository<IHero>
    {
        private List<IHero> heroModels;
        public HeroRepository()
        {
            this.heroModels = new List<IHero>();
        }
        public IReadOnlyCollection<IHero> Models => this.heroModels;

        public void Add(IHero model)
        {
            heroModels.Add(model);
        }

        public IHero FindByName(string name)
        {
            var result = this.heroModels.FirstOrDefault(x => x.Name == name);
            return result;
        }

        public bool Remove(IHero model)
        {
            return this.heroModels.Remove(model);
        }
    }
}
