﻿using Heroes.Models.Contracts;
using Heroes.Models.Heroes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Models.Map
{
    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            Queue<IHero> knightsList = new Queue<IHero>();
            Queue<IHero> barbariansList = new Queue<IHero>();
            foreach (var player in players)
            {
                if (player.GetType().Name==nameof(Barbarian))
                {
                    barbariansList.Enqueue(player);
                }
                else
                {
                    knightsList.Enqueue(player);
                }
            }
            int deadBarbarians = 0;
            int deadKnights = 0;
            while (knightsList.Count > 0 || barbariansList.Count > 0)
            {
                var currentBarbarian = barbariansList.Peek();
                var currentKnight = knightsList.Peek();

                int barbarianHafterAttack = currentBarbarian.Health - currentKnight.Weapon.DoDamage();
                if (barbarianHafterAttack<=0)
                {
                    barbariansList.Dequeue();
                    deadBarbarians++;
                }

                int knightHafterAttack = currentKnight.Health - currentBarbarian.Weapon.DoDamage();
                if (knightHafterAttack <= 0)
                {
                    knightsList.Dequeue();
                    deadKnights++;
                }
            }

            if (knightsList.Count>0)
            {
                return $"The knights took {deadKnights} casualties but won the battle.";
            }
            else
            {
                return $"The barbarians took {deadBarbarians} casualties but won the battle.";
            }
        }
    }
}
