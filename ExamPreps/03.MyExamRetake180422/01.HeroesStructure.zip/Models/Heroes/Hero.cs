﻿using Heroes.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Models.Heroes
{
    public abstract class Hero : IHero
    {
        private string name;
        private int health;
        private int armour;
        private IWeapon weapon;
        private List<IWeapon> weaponList;

        protected Hero(string name, int health, int armour)
        {
            this.Name = name;
            this.Health = health;
            this.Armour = armour;
            weaponList = new List<IWeapon>();
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Hero name cannot be null or empty.");
                }

                this.name = value;
            }
        }

        public int Health
        {
            get
            {
                return this.health;
            }
            private set
            {
                this.health = value;

                if (this.health<0)
                {
                    throw new ArgumentException("Hero health cannot be below 0.");
                }

                
            }
        }

        public int Armour
        {
            get
            {
                return this.armour;
            }
            private set
            {
                this.armour = value;
                if (this.armour < 0)
                {
                    throw new ArgumentException("Hero armour cannot be below 0.");
                }
                
            }
        }


        public IWeapon Weapon 
        {
            get
            {
                return this.weapon;
            }
            private set
            {
                if (value==null)
                {
                    throw new ArgumentException("Weapon cannot be null.");
                }
                this.weapon = value;
            }
        }

        public bool IsAlive => this.Health > 0 ? true : false;

        public void AddWeapon(IWeapon weapon)
        {
            if (weaponList.Count==1)
            {
                return;
            }

            weaponList.Add(weapon);
        }

        public void TakeDamage(int points)
        {
            int leftPoints = points - this.Armour > 0
                ? points - this.Armour
                : 0;

            if (this.Armour - points <=0)
            {
                this.Armour = 0;
                this.Health -= leftPoints;
            }
            else
            {
                this.Armour -= points;
            }
            
            
        }
    }
}
