﻿using System;

namespace Farm
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Dog brian = new Dog();
            brian.Bark();
            brian.Bark();
            brian.Eat();
        }
    }
}
