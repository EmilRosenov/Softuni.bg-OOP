﻿using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        //[TestCase(0, 30)]
        //[TestCase(-1, 30)]
        //public void Ctor_Throws_Error_When_Health_Is_Zero_Or_Less(int health, int experience)
        //{
        //   
        //    Assert.Throws<InvalidOperationException>(() =>
        //    {
        //        Dummy dummy = new Dummy(health, experience);
        //    });
        //}
        public void Dummy_Loses_Health_When_Attacked()
        {
            int attackpoints = 90;
            Dummy dummy = new Dummy(100, 100);
            dummy.TakeAttack(attackpoints);
            Assert.AreEqual(dummy.Health, 10);
        }
        [Test]
        [TestCase(0,100)]
        [TestCase(-1,100)]
        //[TestCase(15,100)]
        public void Dummy_Throws_Exception_hWhen_Attacked(int health, int experiance)
        {
            int attackpoints = 90;
            Dummy dummy = new Dummy(health, experiance);
            Assert.Throws<InvalidOperationException>(() => dummy.TakeAttack(attackpoints));

          
        }
        [Test]
        [TestCase(59, 100)]
        
        public void Test_Dead_Dummy_Gives_Experience(int health, int experiance)
        {
            int newExperiance = 90;
            Dummy dummy = new Dummy(health, experiance);
            dummy.TakeAttack(60);
            newExperiance += experiance;
            Assert.AreEqual(190, newExperiance);
        }
        [Test]
        [TestCase(59, 100)]
        
        public void Tests_When_Dummy_Is_Alive(int health, int experiance)
        {
            int newExperiance = 100;
            Dummy dummy = new Dummy(health, experiance);
            dummy.TakeAttack(58);
            Assert.AreEqual(newExperiance, experiance);
        }

        [Test]
        [TestCase(59, 100)]
        public void Test_Alive_Dummy_Throws_Exception(int health, int experiance)
        { 
            int newExperiance = 90;
            Dummy dummy = new Dummy(health, experiance);
            var ex = Assert.Throws<InvalidOperationException>(() => dummy.TakeAttack(57));
            Assert.That(ex.Message.Equals("Target is not dead."));
        }


    }
}