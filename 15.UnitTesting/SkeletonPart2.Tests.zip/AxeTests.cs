using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {
        [Test]
        public void TestAttackLoosesWeaponDurability()
        {
            Axe axe = new Axe(10, 20);
            axe.Attack(new Dummy(100, 100));
            Assert.AreEqual(axe.DurabilityPoints, 19);
        }
        [Test]
        public void TestAttackWithZeroDurabilityThrowsError()
        {
            Axe axe = new Axe(10, 1);
            axe.Attack(new Dummy(100, 100));
            Assert.Throws<InvalidOperationException>(() =>
            {
                axe.Attack(new Dummy(100, 100));
            });
        }
        [Test]
        public void TestAttackWithNegativeDurabilityThrowsError()
         {
            Axe axe = new Axe(10, -5);
            Assert.Throws<InvalidOperationException>(() =>
            {
                axe.Attack(new Dummy(100, 100));
            });
        }
       
    }
}