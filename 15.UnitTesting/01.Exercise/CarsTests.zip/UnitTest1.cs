using _01.Exercise;
using NUnit.Framework;
using System;

namespace CarsTests
{
    public class Tests
    {
        Cars car = new Cars();

        [Test]
        [TestCase(0)]
        [TestCase(-1)]
        public void Test_Drive_Throws_Exception_When_Km_Less_Or_Equal_To_Zero(int km)
        {
            Assert.Throws<InvalidOperationException>(() => car.Drive(km));
        }

        [Test]
        [TestCase(20)]
        public void Test_Adds_Km_To_Mileage(int km)
        {
            int oldMileage = car.Mileage;
            car.Drive(km);
            car.Mileage += km;
            int newMIleage = car.Mileage;
            Assert.Greater(newMIleage, oldMileage);
        }
    }
}